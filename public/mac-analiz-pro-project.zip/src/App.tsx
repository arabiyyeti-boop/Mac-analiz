// src/App.tsx - MAÇ ANALİZ PRO Application Root
import React, { useState, useEffect, useCallback } from 'react';
import { Header } from '@/components/common/Header';
import { BottomNavigation, NavTab } from '@/components/layout/BottomNavigation';
import { MainHomeView } from '@/features/home/MainHomeView';
import { MatchDetailView } from '@/features/matches/MatchDetailView';
import { SettingsView } from '@/features/settings/SettingsView';
import { CanonicalMatch, MatchAnalysis, AIExplanation, MarketSignal } from '@/types';
import { AppApiService } from '@/services/api';
import { predictionLedger } from '@/prediction/ledger';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('matches');
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);

  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [matches, setMatches] = useState<CanonicalMatch[]>([]);
  const [isLoadingMatches, setIsLoadingMatches] = useState(false);

  const [selectedMatch, setSelectedMatch] = useState<CanonicalMatch | null>(null);
  const [analyses, setAnalyses] = useState<Record<string, MatchAnalysis>>({});
  const [isLoadingAnalysis, setIsLoadingAnalysis] = useState(false);

  const [aiExplanations, setAiExplanations] = useState<Record<string, AIExplanation>>({});
  const [isLoadingAI, setIsLoadingAI] = useState(false);

  const [favorites, setFavorites] = useState<string[]>([]);

  // Online / Offline tracking
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Load favorites
  useEffect(() => {
    AppApiService.getFavorites().then(setFavorites);
  }, []);

  // Fetch matches whenever date changes
  const loadMatches = useCallback(async (date: string) => {
    setIsLoadingMatches(true);
    try {
      const { matches: list } = await AppApiService.getFixtures(date);
      setMatches(list);

      // Pre-analyze the first 2 matches if available for quick experience
      if (list.length > 0) {
        const topMatches = list.slice(0, 2);
        for (const m of topMatches) {
          AppApiService.analyzeMatch(m).then((analysis) => {
            setAnalyses((prev) => ({ ...prev, [m.id]: analysis }));
          });
        }
      }
    } finally {
      setIsLoadingMatches(false);
    }
  }, []);

  useEffect(() => {
    loadMatches(selectedDate);
  }, [selectedDate, loadMatches]);

  // Select match & analyze
  const handleSelectMatch = async (match: CanonicalMatch) => {
    setSelectedMatch(match);

    if (!analyses[match.id]) {
      setIsLoadingAnalysis(true);
      try {
        const analysis = await AppApiService.analyzeMatch(match);
        setAnalyses((prev) => ({ ...prev, [match.id]: analysis }));
      } finally {
        setIsLoadingAnalysis(false);
      }
    }
  };

  // Re-run analysis for current match
  const handleRefreshAnalysis = async () => {
    if (!selectedMatch) return;
    setIsLoadingAnalysis(true);
    try {
      const analysis = await AppApiService.analyzeMatch(selectedMatch);
      setAnalyses((prev) => ({ ...prev, [selectedMatch.id]: analysis }));
    } finally {
      setIsLoadingAnalysis(false);
    }
  };

  // AI explanation request
  const handleRequestAIExplanation = async () => {
    if (!selectedMatch) return;
    const currentAnalysis = analyses[selectedMatch.id];
    if (!currentAnalysis) return;

    setIsLoadingAI(true);
    try {
      const explanation = await AppApiService.getAIExplanation(currentAnalysis);
      setAiExplanations((prev) => ({ ...prev, [selectedMatch.id]: explanation }));
    } finally {
      setIsLoadingAI(false);
    }
  };

  // Toggle favorite
  const handleToggleFavorite = async (matchId: string) => {
    const updated = await AppApiService.toggleFavorite(matchId);
    setFavorites(updated);
  };

  // Record prediction to ledger
  const handleRecordLedger = async (
    analysis: MatchAnalysis,
    signal: MarketSignal,
    oddsData?: {
      snapshotId?: string;
      opening?: number;
      current?: number;
      source?: string;
      overround?: number;
      probabilityEdge?: number;
      squadSnapshotId?: string;
      marketRegime?: string;
      closingOdds?: number;
      clvPercent?: number;
      recordVersion?: string;
    }
  ) => {
    await predictionLedger.recordPrediction(analysis, signal, oddsData);
  };

  // Clear all data
  const handleClearAllData = async () => {
    await AppApiService.clearAllData();
    setFavorites([]);
    setAnalyses({});
    setAiExplanations({});
    await loadMatches(selectedDate);
  };

  // Get active tab title
  const getTabTitle = () => {
    if (selectedMatch) {
      return `${selectedMatch.homeTeam.name} vs ${selectedMatch.awayTeam.name}`;
    }
    switch (activeTab) {
      case 'matches':
        return 'Maçlar';
      case 'favorites':
        return 'Favoriler';
      case 'leagues':
        return 'Ligler';
      case 'search':
        return 'Maç Ara';
      case 'settings':
        return 'Ayarlar';
      default:
        return 'Maçlar';
    }
  };

  const currentAnalysis = selectedMatch ? analyses[selectedMatch.id] || null : null;
  const currentAIExplanation = selectedMatch ? aiExplanations[selectedMatch.id] || null : null;

  return (
    <div className="min-h-screen bg-[#0b1120] text-slate-100 flex flex-col selection:bg-emerald-500/30 selection:text-emerald-200">
      <Header
        isOnline={isOnline}
        activeTabTitle={getTabTitle()}
        onOpenSettings={() => {
          setSelectedMatch(null);
          setActiveTab('settings');
        }}
      />

      <main className="flex-1 max-w-5xl w-full mx-auto px-3 sm:px-6 pt-4">
        {selectedMatch ? (
          <MatchDetailView
            match={selectedMatch}
            analysis={currentAnalysis}
            isLoadingAnalysis={isLoadingAnalysis}
            onBack={() => setSelectedMatch(null)}
            onRefreshAnalysis={handleRefreshAnalysis}
            onRecordLedger={handleRecordLedger}
            aiExplanation={currentAIExplanation}
            isLoadingAI={isLoadingAI}
            onRequestAIExplanation={handleRequestAIExplanation}
          />
        ) : (
          <>
            {activeTab === 'matches' && (
              <MainHomeView
                matches={matches}
                selectedDate={selectedDate}
                onDateChange={setSelectedDate}
                onSelectMatch={handleSelectMatch}
                favorites={favorites}
                onToggleFavorite={handleToggleFavorite}
                isLoading={isLoadingMatches}
              />
            )}

            {activeTab === 'favorites' && (
              <MainHomeView
                matches={matches}
                selectedDate={selectedDate}
                onDateChange={setSelectedDate}
                onSelectMatch={handleSelectMatch}
                favorites={favorites}
                onToggleFavorite={handleToggleFavorite}
                isLoading={isLoadingMatches}
              />
            )}

            {activeTab === 'leagues' && (
              <MainHomeView
                matches={matches}
                selectedDate={selectedDate}
                onDateChange={setSelectedDate}
                onSelectMatch={handleSelectMatch}
                favorites={favorites}
                onToggleFavorite={handleToggleFavorite}
                isLoading={isLoadingMatches}
              />
            )}

            {activeTab === 'search' && (
              <MainHomeView
                matches={matches}
                selectedDate={selectedDate}
                onDateChange={setSelectedDate}
                onSelectMatch={handleSelectMatch}
                favorites={favorites}
                onToggleFavorite={handleToggleFavorite}
                isLoading={isLoadingMatches}
                focusSearch={true}
              />
            )}

            {activeTab === 'settings' && (
              <div className="space-y-4 pb-20">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <h2 className="text-base font-bold text-white">Uygulama Ayarları</h2>
                  <button
                    onClick={() => setActiveTab('matches')}
                    className="text-xs text-emerald-400 font-semibold hover:underline"
                  >
                    Maçlara Dön &rarr;
                  </button>
                </div>
                <SettingsView onClearAllData={handleClearAllData} />
              </div>
            )}
          </>
        )}
      </main>

      <BottomNavigation
        activeTab={activeTab}
        onTabChange={(tab) => {
          setSelectedMatch(null);
          setActiveTab(tab);
        }}
        favoritesCount={favorites.length}
      />
    </div>
  );
}
